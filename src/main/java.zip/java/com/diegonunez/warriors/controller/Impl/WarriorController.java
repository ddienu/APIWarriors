package com.diegonunez.warriors.controller.Impl;

import com.diegonunez.warriors.controller.IWarriorController;
import com.diegonunez.warriors.common.ApiResponse;
import com.diegonunez.warriors.dto.Request.WarriorRequestDTO;
import com.diegonunez.warriors.dto.Response.WarriorResponseDTO;
import com.diegonunez.warriors.entity.BreedWarrior;
import com.diegonunez.warriors.entity.TypePower;
import com.diegonunez.warriors.entity.TypeWarrior;
import com.diegonunez.warriors.entity.Warrior;
import com.diegonunez.warriors.service.Impl.WarriorServiceImpl;
import jakarta.validation.Valid;
import org.apache.coyote.Response;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path = "/v1/warrior")
public class WarriorController implements IWarriorController {

    private final WarriorServiceImpl warriorService;

    public WarriorController ( WarriorServiceImpl warriorService){
        this.warriorService = warriorService;
    }
    @Override
    @GetMapping
    public ResponseEntity<ApiResponse<List<WarriorResponseDTO>>> getAllWarriors() {
        List<WarriorResponseDTO> response = warriorService.getAllWarriors();
        if( response.isEmpty() ){
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(
                    new ApiResponse<>(
                            "No warriors founded",
                            null
                    )
            );
        }else{
            return ResponseEntity.status(HttpStatus.OK).body(
                    new ApiResponse<>(
                            "Warriors retrieved successfully",
                            response
                    )
            );
        }
    }

    @PostMapping
    @Override
    public ResponseEntity<ApiResponse<WarriorResponseDTO>> createWarrior(@Valid @RequestBody WarriorRequestDTO warrior) {
        WarriorResponseDTO result = warriorService.createWarrior(warrior);

        return ResponseEntity.status(HttpStatus.CREATED).body(
                new ApiResponse<>(
                        "Warrior created successfully",
                        result
                )
        );
    }

    @Override
    public ResponseEntity<ApiResponse<WarriorResponseDTO>> updateWarrior(Integer warriorId, WarriorRequestDTO warriorUpdate) {
        WarriorResponseDTO result = warriorService.updateWarrior(warriorId, warriorUpdate);

        return ResponseEntity.status(HttpStatus.OK).body(
                new ApiResponse<>(
                        "Warrior with ID: "+warriorId+" updated successfully",
                        result
                )
        );
    }

    @Override
    public ResponseEntity<ApiResponse<Boolean>> deleteWarrior(Integer warriorId) {
        boolean result = warriorService.deleteWarrior(warriorId);

        return ResponseEntity.status(HttpStatus.NO_CONTENT).body(
                new ApiResponse<>(
                        "Warrior with ID: "+warriorId+" deleted successfully",
                        result
                )
        );
    }

}
