package com.diegonunez.warriors.controller;

import com.diegonunez.warriors.common.ApiResponse;
import com.diegonunez.warriors.dto.Request.BreedWarriorRequestDTO;
import com.diegonunez.warriors.dto.Response.BreedWarriorResponseDTO;
import com.diegonunez.warriors.entity.BreedWarrior;
import jakarta.validation.Valid;
import org.apache.coyote.Response;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

public interface IBreedWarriorController {
    ResponseEntity<ApiResponse<List<BreedWarriorResponseDTO>>>  getAllBreedWarrior();
    ResponseEntity<ApiResponse<BreedWarriorResponseDTO>> createBreedWarrior(@Valid @RequestBody BreedWarriorRequestDTO breedWarrior);
    ResponseEntity<ApiResponse<BreedWarriorResponseDTO>> updateBreedWarrior(@PathVariable Integer breedId, @Valid @RequestBody BreedWarriorRequestDTO breedWarriorUpdate);
    ResponseEntity<ApiResponse<Boolean>> deleteBreedWarrior(@PathVariable Integer breedId);
}
