package com.diegonunez.warriors.controller;

import com.diegonunez.warriors.common.ApiResponse;
import com.diegonunez.warriors.dto.Request.WarriorRequestDTO;
import com.diegonunez.warriors.dto.Response.WarriorResponseDTO;
import com.diegonunez.warriors.entity.BreedWarrior;
import com.diegonunez.warriors.entity.TypePower;
import com.diegonunez.warriors.entity.TypeWarrior;
import com.diegonunez.warriors.entity.Warrior;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

public interface IWarriorController {

    ResponseEntity<ApiResponse<List<WarriorResponseDTO>>> getAllWarriors();
    ResponseEntity<ApiResponse<WarriorResponseDTO>> createWarrior(@Valid @RequestBody WarriorRequestDTO warrior);
    @PutMapping(path = "/{warriorId}")
    ResponseEntity<ApiResponse<WarriorResponseDTO>> updateWarrior(@PathVariable Integer warriorId, @RequestBody WarriorRequestDTO warriorUpdate);
    @DeleteMapping(path = "/{warriorId}")
    ResponseEntity<ApiResponse<Boolean>> deleteWarrior(@PathVariable Integer warriorId);
}
