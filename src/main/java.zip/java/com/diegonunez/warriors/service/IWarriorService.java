package com.diegonunez.warriors.service;

import com.diegonunez.warriors.common.ApiResponse;
import com.diegonunez.warriors.dto.Request.WarriorRequestDTO;
import com.diegonunez.warriors.dto.Response.WarriorResponseDTO;
import com.diegonunez.warriors.entity.BreedWarrior;
import com.diegonunez.warriors.entity.TypePower;
import com.diegonunez.warriors.entity.TypeWarrior;
import com.diegonunez.warriors.entity.Warrior;

import java.util.List;

public interface IWarriorService {
    List<WarriorResponseDTO> getAllWarriors();
    WarriorResponseDTO createWarrior(WarriorRequestDTO warrior);

    WarriorResponseDTO updateWarrior(Integer warriorId, WarriorRequestDTO warriorUpdated);
    boolean deleteWarrior(Integer warriorId);
}
