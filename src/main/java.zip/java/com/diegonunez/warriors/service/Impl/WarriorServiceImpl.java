package com.diegonunez.warriors.service.Impl;

import com.diegonunez.warriors.dto.Request.WarriorRequestDTO;
import com.diegonunez.warriors.dto.Response.BreedWarriorResponseDTO;
import com.diegonunez.warriors.dto.Response.TypePowerResponseDTO;
import com.diegonunez.warriors.dto.Response.TypeWarriorResponseDTO;
import com.diegonunez.warriors.dto.Response.WarriorResponseDTO;
import com.diegonunez.warriors.entity.BreedWarrior;
import com.diegonunez.warriors.entity.TypePower;
import com.diegonunez.warriors.entity.TypeWarrior;
import com.diegonunez.warriors.entity.Warrior;
import com.diegonunez.warriors.exception.Unchecked.EmptyListException;
import com.diegonunez.warriors.repository.IBreedWarriorRepository;
import com.diegonunez.warriors.repository.ITypePowerRepository;
import com.diegonunez.warriors.repository.ITypeWarriorRepository;
import com.diegonunez.warriors.repository.IWarriorRepository;
import com.diegonunez.warriors.service.IWarriorService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class WarriorServiceImpl implements IWarriorService {
    private final IWarriorRepository warriorRepository;
    private final IBreedWarriorRepository breedWarriorRepository;
    private final ITypePowerRepository typePowerRepository;
    private final ITypeWarriorRepository typeWarriorRepository;

    public WarriorServiceImpl( IWarriorRepository warriorRepository, IBreedWarriorRepository breedWarriorRepository
                               ,ITypePowerRepository typePowerRepository, ITypeWarriorRepository typeWarriorRepository){
        this.warriorRepository = warriorRepository;
        this.breedWarriorRepository = breedWarriorRepository;
        this.typePowerRepository = typePowerRepository;
        this.typeWarriorRepository = typeWarriorRepository;
    }
    @Override
    public List<WarriorResponseDTO> getAllWarriors() {

        List<Warrior> warriorListDB = warriorRepository.findAll();
        List<WarriorResponseDTO> warriorResponseList = warriorListDB.stream().map(
                warrior -> new WarriorResponseDTO(
                        warrior.getWarriorId(),
                        warrior.getWarriorName(),
                        warrior.getWarriorLife(),
                        warrior.getWarriorEnergy(),
                        new TypeWarriorResponseDTO(
                                warrior.getTypeOfWarrior().getTypeWarriorId(),
                                warrior.getTypeOfWarrior().getTypeWarriorName(),
                                warrior.getTypeOfWarrior().getTypeWarriorDescription()
                        ),
                        warrior.getTypeOfPower().stream().map(
                                warriorTypePower -> new TypePowerResponseDTO(
                                    warriorTypePower.getPowerId(),
                                        warriorTypePower.getPowerName(),
                                        warriorTypePower.getPowerDamage(),
                                        warriorTypePower.getPowerEnergyConsumed(),
                                        warriorTypePower.getPowerDescription()
                            )
                        ).toList(),
                        new BreedWarriorResponseDTO(
                                warrior.getBreedWarrior().getBreedId(),
                                warrior.getBreedWarrior().getBreedName(),
                                warrior.getBreedWarrior().getBreedDescription(),
                                warrior.getBreedWarrior().getBreedResistance()
                        )
                )
        ).toList();

        if( warriorResponseList.isEmpty()){
            throw new EmptyListException("Warriors not found");
        }

        return warriorResponseList;
    }
    @Transactional
    @Override
    public WarriorResponseDTO createWarrior(WarriorRequestDTO warrior) throws EntityNotFoundException  {
        BreedWarrior breedWarrior = breedWarriorRepository.findById(warrior.getBreedWarrior().getBreedId()).orElseThrow(
                () -> new EntityNotFoundException("Breed of warrior not found")
        );

        TypeWarrior typeWarrior = typeWarriorRepository.findById(warrior.getTypeOfWarrior().getTypeWarriorId()).orElseThrow(
                () -> new EntityNotFoundException("Type warrior not found")
        );

        List<TypePower> powers = typePowerRepository.findAllById(warrior.getPowers().stream().map(
                powerIds -> powerIds.getPowerId()).collect(Collectors.toList())
        );

        Warrior newWarrior = new Warrior();
        newWarrior.setWarriorName(warrior.getWarriorName());
        newWarrior.setWarriorEnergy(warrior.getWarriorEnergy());
        newWarrior.setWarriorLife(warrior.getWarriorLife());
        newWarrior.setBreedWarrior(breedWarrior);
        newWarrior.setTypeOfWarrior(typeWarrior);
        newWarrior.setTypeOfPower(powers);

        warriorRepository.save(newWarrior);

       return new WarriorResponseDTO(
                newWarrior.getWarriorId(),
                newWarrior.getWarriorName(),
                newWarrior.getWarriorLife(),
                newWarrior.getWarriorEnergy(),
               new TypeWarriorResponseDTO(
                       newWarrior.getTypeOfWarrior().getTypeWarriorId(),
                       newWarrior.getTypeOfWarrior().getTypeWarriorName(),
                       newWarrior.getTypeOfWarrior().getTypeWarriorDescription()
               ),
                newWarrior.getTypeOfPower().stream().map(
                        warriorTypePower -> new TypePowerResponseDTO(
                                warriorTypePower.getPowerId(),
                                warriorTypePower.getPowerName(),
                                warriorTypePower.getPowerDamage(),
                                warriorTypePower.getPowerEnergyConsumed(),
                                warriorTypePower.getPowerDescription()
                        )
                ).toList(),
                new BreedWarriorResponseDTO(
                        breedWarrior.getBreedId(),
                        breedWarrior.getBreedName(),
                        breedWarrior.getBreedDescription(),
                        breedWarrior.getBreedResistance()
                )
       );
    }

    @Override
        public WarriorResponseDTO updateWarrior(Integer warriorId, WarriorRequestDTO warriorUpdated) {
            Warrior warriorFounded = warriorRepository.findById(warriorId).orElseThrow(
                    () -> new EntityNotFoundException("Warrior with ID: "+warriorId+" not founded")
            );

            warriorFounded.setWarriorName(warriorUpdated.getWarriorName());
            warriorFounded.setWarriorLife(warriorUpdated.getWarriorLife());
            warriorFounded.setWarriorEnergy(warriorUpdated.getWarriorEnergy());
            warriorFounded.setTypeOfWarrior(new TypeWarrior(
                    warriorUpdated.getTypeOfWarrior().getTypeWarriorId(),
                    warriorUpdated.getTypeOfWarrior().getTypeWarriorName(),
                    warriorUpdated.getTypeOfWarrior().getTypeWarriorDescription()
            ));
            warriorFounded.setTypeOfPower(
                    typePowerRepository.findAllById(
                            warriorUpdated.getPowers().stream().map(
                                    power -> power.getPowerId()
                            ).collect(Collectors.toList())
                    )
            );
            warriorFounded.setBreedWarrior(new BreedWarrior(
                    warriorUpdated.getBreedWarrior().getBreedName(),
                    warriorUpdated.getBreedWarrior().getBreedDescription(),
                    warriorUpdated.getBreedWarrior().getBreedResistance()
                    )
            );

            return new WarriorResponseDTO(
                    warriorFounded.getWarriorId(),
                    warriorFounded.getWarriorName(),
                    warriorFounded.getWarriorLife(),
                    warriorFounded.getWarriorEnergy(),
                    new TypeWarriorResponseDTO(
                        warriorFounded.getTypeOfWarrior().getTypeWarriorId(),
                        warriorFounded.getTypeOfWarrior().getTypeWarriorName(),
                        warriorFounded.getTypeOfWarrior().getTypeWarriorDescription()
                    ),
                    warriorFounded.getTypeOfPower().stream().map(
                            warriorPowers -> new TypePowerResponseDTO(
                                    warriorPowers.getPowerId(),
                                    warriorPowers.getPowerName(),
                                    warriorPowers.getPowerDamage(),
                                    warriorPowers.getPowerEnergyConsumed(),
                                    warriorPowers.getPowerDescription()
                            )
                    ).collect(Collectors.toList()),
                    new BreedWarriorResponseDTO(
                        warriorFounded.getBreedWarrior().getBreedId(),
                        warriorFounded.getBreedWarrior().getBreedName(),
                        warriorFounded.getBreedWarrior().getBreedDescription(),
                        warriorFounded.getBreedWarrior().getBreedResistance()
                    )

                    );

        }

    @Override
    public boolean deleteWarrior(Integer warriorId) {
        Warrior warriorFounded = warriorRepository.findById(warriorId).orElseThrow(
                () -> new EntityNotFoundException("Warrior with ID: "+warriorId+" not founded")
        );

        warriorRepository.delete(warriorFounded);
        return true;
    }

}
