package com.diegonunez.warriors.repository;

import com.diegonunez.warriors.entity.BreedWarrior;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IBreedWarriorRepository extends JpaRepository<BreedWarrior, Integer> {
}
