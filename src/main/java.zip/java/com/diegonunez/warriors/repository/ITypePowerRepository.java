package com.diegonunez.warriors.repository;

import com.diegonunez.warriors.entity.TypePower;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ITypePowerRepository extends JpaRepository<TypePower, Integer> {
}
