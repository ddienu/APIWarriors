package com.diegonunez.warriors.exception.Unchecked;

public class EmptyListException extends RuntimeException{

    public EmptyListException(String message){
        super(message);
    }
}
