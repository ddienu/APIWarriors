package com.diegonunez.warriors.dto.Request;

import com.diegonunez.warriors.dto.Response.BreedWarriorResponseDTO;
import com.diegonunez.warriors.dto.Response.TypePowerResponseDTO;
import com.diegonunez.warriors.dto.Response.TypeWarriorResponseDTO;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.List;

public class WarriorRequestDTO {

    @NotNull(message = "Warrior's name cannot be null")
    @NotBlank(message = "Warrior's name cannot be empty")
    private String warriorName;
    @NotNull(message = "Warrior's life cannot be null")
    private Double warriorLife;
    @NotNull(message = "Warrior's energy cannot be null")
    private Double warriorEnergy;
    @JsonProperty(value = "warriorType")
    @NotNull(message = "Warrior type cannot be null")
    private TypeWarriorResponseDTO typeOfWarrior;
    @NotNull(message = "Warrior's powers cannot be null")
    private List<TypePowerResponseDTO> powers;
    @NotNull(message = "Warrior's breed cannot be null")
    private BreedWarriorResponseDTO breedWarrior;

    public WarriorRequestDTO(String warriorName, Double warriorLife, Double warriorEnergy, TypeWarriorResponseDTO typeOfWarrior
                             , List<TypePowerResponseDTO> powers, BreedWarriorResponseDTO breedWarrior){
        this.warriorName = warriorName;
        this.warriorLife = warriorLife;
        this.warriorEnergy = warriorEnergy;
        this.typeOfWarrior = typeOfWarrior;
        this.powers = powers;
        this.breedWarrior = breedWarrior;
    }

    public String getWarriorName() {
        return warriorName;
    }

    public void setWarriorName(String warriorName) {
        this.warriorName = warriorName;
    }

    public Double getWarriorLife() {
        return warriorLife;
    }

    public void setWarriorLife(Double warriorLife) {
        this.warriorLife = warriorLife;
    }

    public Double getWarriorEnergy() {
        return warriorEnergy;
    }

    public void setWarriorEnergy(Double warriorEnergy) {
        this.warriorEnergy = warriorEnergy;
    }

    public TypeWarriorResponseDTO getTypeOfWarrior() {
        return typeOfWarrior;
    }

    public void setTypeOfWarrior(TypeWarriorResponseDTO typeOfWarrior) {
        this.typeOfWarrior = typeOfWarrior;
    }

    public List<TypePowerResponseDTO> getPowers() {
        return powers;
    }

    public void setPowers(List<TypePowerResponseDTO> powers) {
        this.powers = powers;
    }

    public BreedWarriorResponseDTO getBreedWarrior() {
        return breedWarrior;
    }

    public void setBreedWarrior(BreedWarriorResponseDTO breedWarrior) {
        this.breedWarrior = breedWarrior;
    }
}
